import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-case-form',
  templateUrl: './case-form.component.html',
  styleUrls: ['./case-form.component.scss']
})
export class CaseFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
