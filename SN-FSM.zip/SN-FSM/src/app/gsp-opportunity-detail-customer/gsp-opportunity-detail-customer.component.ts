import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gsp-opportunity-detail-customer',
  templateUrl: './gsp-opportunity-detail-customer.component.html',
  styleUrls: ['./gsp-opportunity-detail-customer.component.scss']
})
export class GspOpportunityDetailCustomerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
