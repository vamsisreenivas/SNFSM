import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {HttpClient} from '@angular/common/http';
import { InteractionService } from '../interaction.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-gsp-opportunity-detail-info',
  templateUrl: './gsp-opportunity-detail-info.component.html',
  styleUrls: ['./gsp-opportunity-detail-info.component.scss']
})
export class GspOpportunityDetailInfoComponent implements OnInit {

  
  users:any;
  caseNumber:any;
  user_number:string;

  constructor(private route: Router, private route1: ActivatedRoute, private http:HttpClient, private http1:HttpClient, private _interactionService: InteractionService) { }


  ngOnInit() {
    this._interactionService.userNumber$.subscribe( res => this.users = res);
    // let id = this.route1.snapshot.paramMap.get('id');
    // this.caseNumber = id;
    // console.log("Route case "+this.caseNumber);
    // this.http.get<any>('/api/now/table/sn_customerservice_case?sysparm_query=number%3D'+this.caseNumber+'&sysparm_display_value=true').subscribe( (res) => {
    // this.users = res.result[0];
    // return this.users;
    // });

    // this._interactionService.userNumber$.subscribe( number2 => this.user_number = number2);
    // console.log("user_number "+this.user_number);
    // this.http.get<any>('/api/now/table/sn_customerservice_case?sysparm_query=number%3D'+this.user_number+'&sysparm_display_value=true').subscribe( (res) => {
    //   this.users = res.result[0];
    //   console.log(this.users);
    //   console.log(this.users.number);
    //   this._interactionService.sendAst(this.users.asset.display_value);
    //   return this.users;
    // });
    
  }

  goToAssessmentPage() {
    this.route.navigate(['/assessment']);
  }

  goToKnowledgePage(){
    this.route.navigate(['/knowledge']);
  }
  goToSLAPage(){
    this.route.navigate(['/sla']);

  }
}
