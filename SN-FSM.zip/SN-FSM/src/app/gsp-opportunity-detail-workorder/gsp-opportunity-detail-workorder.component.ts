import { Component, OnInit } from '@angular/core';
import { InteractionService } from '../interaction.service';

@Component({
  selector: 'app-gsp-opportunity-detail-workorder',
  templateUrl: './gsp-opportunity-detail-workorder.component.html',
  styleUrls: ['./gsp-opportunity-detail-workorder.component.scss']
})
export class GspOpportunityDetailWorkorderComponent implements OnInit {

  constructor(private _interactionService: InteractionService) { }

  wo:any;

  ngOnInit() {
    this._interactionService.workorder$.subscribe( res => this.wo = res);
  }
  openInDetail(){
    console.log("Opened");
  }
}
