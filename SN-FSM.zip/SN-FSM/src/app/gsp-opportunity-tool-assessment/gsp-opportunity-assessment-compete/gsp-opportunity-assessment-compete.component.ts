import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gsp-opportunity-assessment-compete',
  templateUrl: './gsp-opportunity-assessment-compete.component.html',
  styleUrls: ['./gsp-opportunity-assessment-compete.component.scss']
})
export class GspOpportunityAssessmentCompeteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
