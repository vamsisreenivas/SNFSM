import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gsp-opportunity-assessment-opportunity',
  templateUrl: './gsp-opportunity-assessment-opportunity.component.html',
  styleUrls: ['./gsp-opportunity-assessment-opportunity.component.scss']
})
export class GspOpportunityAssessmentOpportunityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
