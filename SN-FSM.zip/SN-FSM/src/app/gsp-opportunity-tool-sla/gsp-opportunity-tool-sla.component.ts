import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gsp-opportunity-tool-sla',
  templateUrl: './gsp-opportunity-tool-sla.component.html',
  styleUrls: ['./gsp-opportunity-tool-sla.component.scss']
})
export class GspOpportunityToolSlaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
