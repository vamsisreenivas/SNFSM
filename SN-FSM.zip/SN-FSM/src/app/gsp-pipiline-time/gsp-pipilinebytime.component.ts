import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gsp-pipilinebytime',
  templateUrl: './gsp-pipilinebytime.component.html',
  styleUrls: ['./gsp-pipilinebytime.component.scss']
})
export class GspPipilinebytimeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
